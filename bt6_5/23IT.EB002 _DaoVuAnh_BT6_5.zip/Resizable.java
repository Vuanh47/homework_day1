package bt6_5;

public interface Resizable {
	public void resize(double percent);
}
